<?php
/*
* @package JoomShopping for Joomla!
* @subpackage payment
* @author beagler.ru
* @copyright Copyright (C) 2017 beagler.ru. All rights reserved.
* @license GNU General Public License version 2 or later
*/

//защита от прямого доступа
defined('_JEXEC') or die(); ?>

<script type="text/javascript">
	function check_pm_invoicebox() {
		jQuery('#payment_form').submit();
	}
</script>